import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-black/5 dark:border-white/10 mt-20">
      <div className="max-w-6xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-4 gap-8 text-sm">
        <div>
          <p className="font-display font-bold text-lg mb-2">PharmaGardeBénin</p>
          <p className="text-black/60 dark:text-white/60">
            Trouvez rapidement une pharmacie de garde, partout au Bénin.
          </p>
        </div>
        <div>
          <p className="font-semibold mb-2">Navigation</p>
          <ul className="space-y-1 text-black/60 dark:text-white/60">
            <li><Link href="/trouver-une-pharmacie">Trouver une pharmacie</Link></li>
            <li><Link href="/pharmacies-de-garde">Pharmacies de garde</Link></li>
            <li><Link href="/carte">Carte interactive</Link></li>
            <li><Link href="/pharmacies">Toutes les pharmacies</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold mb-2">Informations</p>
          <ul className="space-y-1 text-black/60 dark:text-white/60">
            <li><Link href="/a-propos">À propos</Link></li>
            <li><Link href="/faq">FAQ</Link></li>
            <li><Link href="/confidentialite">Politique de confidentialité</Link></li>
            <li><Link href="/conditions">Conditions d'utilisation</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold mb-2">Contact</p>
          <ul className="space-y-1 text-black/60 dark:text-white/60">
            <li>contact@pharmagardebenin.bj</li>
            <li>+229 XX XX XX XX</li>
          </ul>
        </div>
      </div>
      <div className="text-center text-xs text-black/40 dark:text-white/40 pb-6">
        © {new Date().getFullYear()} PharmaGardeBénin. Tous droits réservés.
      </div>
    </footer>
  );
}
