"use client";
import { useState } from "react";

export default function SearchBar({ onSearch, placeholder = "Nom, commune, quartier..." }) {
  const [value, setValue] = useState("");

  function handleChange(e) {
    const v = e.target.value;
    setValue(v);
    onSearch?.(v);
  }

  return (
    <div className="flex items-center gap-2 card !rounded-full px-4 py-3 w-full">
      <span aria-hidden>🔍</span>
      <input
        type="text"
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        className="flex-1 bg-transparent outline-none text-sm md:text-base placeholder:text-black/40 dark:placeholder:text-white/40"
        aria-label="Rechercher une pharmacie"
      />
    </div>
  );
}
