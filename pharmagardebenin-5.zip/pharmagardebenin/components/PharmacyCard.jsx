"use client";
import { computeStatus, STATUS_META, formatPhoneForWhatsApp } from "@/lib/utils";

export default function PharmacyCard({ pharmacy, distance }) {
  const status = computeStatus(pharmacy);
  const meta = STATUS_META[status];

  return (
    <div className="card overflow-hidden animate-fadeUp">
      <div className="h-40 bg-pharma-gray dark:bg-white/10 relative">
        {/* Remplacer par next/image avec une vraie photo en production */}
        <div className="absolute inset-0 flex items-center justify-center text-black/30 dark:text-white/30 text-sm">
          {pharmacy.nom}
        </div>
        <span className={`absolute top-3 right-3 flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-white/90 dark:bg-black/60 ${meta.text}`}>
          <span className={`status-dot ${meta.color}`} />
          {meta.label}
        </span>
      </div>

      <div className="p-4 space-y-1">
        <h3 className="font-display font-semibold text-base">{pharmacy.nom}</h3>
        <p className="text-sm text-black/60 dark:text-white/60">
          {pharmacy.quartier}, {pharmacy.commune}
        </p>
        <p className="text-xs text-black/50 dark:text-white/50">{pharmacy.horaires}</p>
        {typeof distance === "number" && (
          <p className="text-xs font-medium text-pharma-blue">{distance.toFixed(1)} km</p>
        )}

        <div className="flex flex-wrap gap-2 pt-3">
          <a href={`tel:${pharmacy.telephone}`} className="btn-secondary !px-3 !py-2 text-xs">
            📞 Appeler
          </a>
          {pharmacy.whatsapp && (
            <a
              href={`https://wa.me/${formatPhoneForWhatsApp(pharmacy.whatsapp)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary !px-3 !py-2 text-xs"
            >
              💬 WhatsApp
            </a>
          )}
          <a
            href={`https://www.google.com/maps/dir/?api=1&destination=${pharmacy.latitude},${pharmacy.longitude}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary !px-3 !py-2 text-xs"
          >
            🧭 Itinéraire
          </a>
        </div>
      </div>
    </div>
  );
}
