"use client";
import { GoogleMap, Marker, InfoWindow, useJsApiLoader } from "@react-google-maps/api";
import { useState } from "react";
import { computeStatus } from "@/lib/utils";

const containerStyle = { width: "100%", height: "100%" };
const defaultCenter = { lat: 6.3703, lng: 2.3912 }; // Cotonou

const STATUS_ICON_COLOR = {
  OUVERTE: "green",
  DE_GARDE: "red",
  FERMEE: "gray",
};

export default function MapView({ pharmacies, userLocation }) {
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || "",
  });
  const [selected, setSelected] = useState(null);

  if (!isLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center text-sm text-black/50">
        Chargement de la carte...
      </div>
    );
  }

  return (
    <GoogleMap
      mapContainerStyle={containerStyle}
      center={userLocation || defaultCenter}
      zoom={13}
      options={{ disableDefaultUI: true, zoomControl: true }}
    >
      {userLocation && (
        <Marker
          position={userLocation}
          icon={{
            url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
          }}
          title="Votre position"
        />
      )}

      {pharmacies.map((p) => {
        const status = computeStatus(p);
        return (
          <Marker
            key={p.id}
            position={{ lat: p.latitude, lng: p.longitude }}
            icon={{
              url: `https://maps.google.com/mapfiles/ms/icons/${STATUS_ICON_COLOR[status]}-dot.png`,
            }}
            onClick={() => setSelected(p)}
          />
        );
      })}

      {selected && (
        <InfoWindow
          position={{ lat: selected.latitude, lng: selected.longitude }}
          onCloseClick={() => setSelected(null)}
        >
          <div className="text-sm text-black">
            <p className="font-semibold">{selected.nom}</p>
            <p>{selected.quartier}, {selected.commune}</p>
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
}
