"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

const NAV = [
  { href: "/", label: "Accueil" },
  { href: "/trouver-une-pharmacie", label: "Trouver une pharmacie" },
  { href: "/pharmacies-de-garde", label: "Pharmacies de garde" },
  { href: "/carte", label: "Carte interactive" },
  { href: "/pharmacies", label: "Toutes les pharmacies" },
  { href: "/a-propos", label: "À propos" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const [dark, setDark] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <header className="sticky top-0 z-50 glass">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-display font-bold text-lg">
          <span className="w-8 h-8 rounded-full bg-pharma-blue text-white flex items-center justify-center text-sm">
            PG
          </span>
          PharmaGardeBénin
        </Link>

        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} className="hover:text-pharma-blue transition">
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            aria-label="Basculer le mode sombre"
            onClick={() => setDark((d) => !d)}
            className="w-10 h-10 rounded-full border border-black/10 dark:border-white/10 flex items-center justify-center"
          >
            {dark ? "☀️" : "🌙"}
          </button>
          <button
            className="lg:hidden w-10 h-10 rounded-full border border-black/10 dark:border-white/10 flex items-center justify-center"
            onClick={() => setOpen((o) => !o)}
            aria-label="Ouvrir le menu"
          >
            ☰
          </button>
        </div>
      </div>

      {open && (
        <nav className="lg:hidden px-6 pb-4 flex flex-col gap-3 text-sm font-medium">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} onClick={() => setOpen(false)}>
              {item.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
