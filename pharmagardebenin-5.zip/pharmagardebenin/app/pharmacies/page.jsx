"use client";
import { useState } from "react";
import SearchBar from "@/components/SearchBar";
import PharmacyCard from "@/components/PharmacyCard";
import { pharmacies, searchPharmacies } from "@/lib/pharmacies";

export default function ToutesLesPharmaciesPage() {
  const [query, setQuery] = useState("");
  const results = searchPharmacies(pharmacies, query);

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <h1 className="font-display font-bold text-3xl mb-2">Toutes les pharmacies</h1>
      <p className="text-black/60 dark:text-white/60 mb-8">
        {pharmacies.length} pharmacies référencées sur PharmaGardeBénin.
      </p>

      <div className="mb-8 max-w-xl">
        <SearchBar onSearch={setQuery} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {results.map((p) => (
          <PharmacyCard key={p.id} pharmacy={p} />
        ))}
      </div>
    </div>
  );
}
