"use client";
import { useState } from "react";
import SearchBar from "@/components/SearchBar";
import PharmacyCard from "@/components/PharmacyCard";
import { pharmacies, searchPharmacies } from "@/lib/pharmacies";
import { distanceKm } from "@/lib/utils";

export default function TrouverPharmaciePage() {
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState(null);
  const [error, setError] = useState("");

  function localiser() {
    if (!navigator.geolocation) {
      setError("La géolocalisation n'est pas disponible sur cet appareil.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setError("Impossible d'obtenir votre position. Autorisez la localisation.")
    );
  }

  let results = searchPharmacies(pharmacies, query);
  if (location) {
    results = results
      .map((p) => ({ ...p, _distance: distanceKm(location.lat, location.lng, p.latitude, p.longitude) }))
      .sort((a, b) => a._distance - b._distance);
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <h1 className="font-display font-bold text-3xl mb-2">Trouver une pharmacie</h1>
      <p className="text-black/60 dark:text-white/60 mb-8">
        Recherchez par nom, département, commune, arrondissement ou quartier.
      </p>

      <div className="flex flex-col md:flex-row gap-4 mb-4">
        <SearchBar onSearch={setQuery} />
        <button onClick={localiser} className="btn-primary whitespace-nowrap">
          📍 Me localiser
        </button>
      </div>

      {error && <p className="text-sm text-red-500 mb-4">{error}</p>}
      {location && !error && (
        <p className="text-sm text-pharma-blue mb-6">
          Vous êtes à proximité de {results[0]?.nom} ({results[0]?._distance.toFixed(1)} km)
        </p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {results.map((p) => (
          <PharmacyCard key={p.id} pharmacy={p} distance={p._distance} />
        ))}
        {results.length === 0 && (
          <p className="col-span-full text-center text-black/50 py-12">Aucune pharmacie trouvée.</p>
        )}
      </div>
    </div>
  );
}
