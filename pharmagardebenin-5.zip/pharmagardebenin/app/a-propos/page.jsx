export const metadata = { title: "À propos — PharmaGardeBénin" };

export default function AProposPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display font-bold text-3xl mb-6">À propos de PharmaGardeBénin</h1>
      <div className="space-y-4 text-black/70 dark:text-white/70 leading-relaxed">
        <p>
          PharmaGardeBénin est né d'un constat simple : la nuit, un dimanche ou un jour férié,
          trouver rapidement une pharmacie ouverte au Bénin reste souvent difficile.
        </p>
        <p>
          Notre plateforme centralise en un seul endroit la localisation, les horaires et le
          statut de garde de chaque pharmacie du territoire, avec un itinéraire précis et un
          contact direct.
        </p>
        <p>
          Nous démarrons avec Cotonou et Abomey-Calavi, avec pour ambition de couvrir
          progressivement Porto-Novo, Parakou, Abomey, Bohicon puis l'ensemble du pays.
        </p>
      </div>
    </div>
  );
}
