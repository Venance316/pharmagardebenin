export const metadata = { title: "Conditions d'utilisation — PharmaGardeBénin" };

export default function ConditionsPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display font-bold text-3xl mb-6">Conditions d'utilisation</h1>
      <div className="space-y-5 text-black/70 dark:text-white/70 leading-relaxed text-sm">
        <p>
          L'utilisation de PharmaGardeBénin implique l'acceptation pleine et entière des
          présentes conditions.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Objet du service</h2>
        <p>
          PharmaGardeBénin fournit des informations sur les pharmacies (localisation, horaires,
          statut de garde) à titre indicatif. En cas d'urgence médicale, contactez immédiatement
          les services d'urgence.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Exactitude des informations</h2>
        <p>
          Nous mettons tout en œuvre pour garantir l'exactitude des informations, mais ne
          pouvons garantir l'absence totale d'erreur ou de retard de mise à jour.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Responsabilité</h2>
        <p>
          PharmaGardeBénin ne saurait être tenu responsable des conséquences directes ou
          indirectes liées à l'utilisation des informations fournies.
        </p>
      </div>
    </div>
  );
}
