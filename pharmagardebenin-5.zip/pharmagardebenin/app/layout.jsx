import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata = {
  title: "PharmaGardeBénin — Trouvez une pharmacie de garde",
  description:
    "Trouvez rapidement une pharmacie de garde ou la pharmacie ouverte la plus proche, partout au Bénin.",
  manifest: "/manifest.json",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body className="font-body min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
