import PharmacyCard from "@/components/PharmacyCard";
import { pharmacies } from "@/lib/pharmacies";

export const metadata = { title: "Pharmacies de garde — PharmaGardeBénin" };

export default function PharmaciesDeGardePage() {
  const deGarde = pharmacies.filter((p) => p.deGarde);

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <h1 className="font-display font-bold text-3xl mb-2">Pharmacies de garde</h1>
      <p className="text-black/60 dark:text-white/60 mb-8">
        Ces pharmacies restent ouvertes de 20h30 à 07h00 selon le planning officiel de garde.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {deGarde.map((p) => (
          <PharmacyCard key={p.id} pharmacy={p} />
        ))}
        {deGarde.length === 0 && (
          <p className="col-span-full text-center text-black/50 py-12">
            Aucune pharmacie de garde enregistrée pour le moment.
          </p>
        )}
      </div>
    </div>
  );
}
