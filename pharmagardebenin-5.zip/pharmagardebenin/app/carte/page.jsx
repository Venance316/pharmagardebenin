"use client";
import { useEffect, useState } from "react";
import MapView from "@/components/MapView";
import { pharmacies } from "@/lib/pharmacies";

export default function CartePage() {
  const [location, setLocation] = useState(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) =>
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude })
      );
    }
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <h1 className="font-display font-bold text-3xl mb-2">Carte interactive</h1>
      <p className="text-black/60 dark:text-white/60 mb-6">
        🟢 Ouverte · 🔴 Pharmacie de garde · ⚪ Fermée
      </p>
      <div className="h-[520px] rounded-xl2 overflow-hidden shadow-soft">
        <MapView pharmacies={pharmacies} userLocation={location} />
      </div>
    </div>
  );
}
