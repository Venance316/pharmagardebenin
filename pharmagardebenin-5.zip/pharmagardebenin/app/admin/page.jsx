"use client";
import { useState } from "react";
import { pharmacies as seed } from "@/lib/pharmacies";

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [form, setForm] = useState({ email: "", password: "" });
  const [list, setList] = useState(seed);
  const [error, setError] = useState("");

  async function login(e) {
    e.preventDefault();
    // En production : POST /api/auth/login -> reçoit un JWT (voir /backend)
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      }).catch(() => null);

      if (res && res.ok) {
        setAuthed(true);
      } else {
        // Démo hors-ligne : accepte si backend indisponible (à retirer en prod)
        setError("Connexion au serveur impossible. Vérifiez /backend.");
      }
    } catch {
      setError("Connexion au serveur impossible. Vérifiez /backend.");
    }
  }

  function toggleGarde(id) {
    setList((l) => l.map((p) => (p.id === id ? { ...p, deGarde: !p.deGarde } : p)));
  }

  function removePharmacy(id) {
    setList((l) => l.filter((p) => p.id !== id));
  }

  if (!authed) {
    return (
      <div className="max-w-md mx-auto px-6 py-24">
        <h1 className="font-display font-bold text-2xl mb-6 text-center">Espace administrateur</h1>
        <form onSubmit={login} className="card p-6 space-y-4">
          <input
            required
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-4 py-3"
          />
          <input
            required
            type="password"
            placeholder="Mot de passe"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-4 py-3"
          />
          <button type="submit" className="btn-primary w-full">Se connecter</button>
          {error && <p className="text-xs text-red-500">{error}</p>}
        </form>
      </div>
    );
  }

  const stats = {
    total: list.length,
    ouvertes: list.filter((p) => p.ouvertureNormale).length,
    garde: list.filter((p) => p.deGarde).length,
    communes: new Set(list.map((p) => p.commune)).size,
    departements: new Set(list.map((p) => p.departement)).size,
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display font-bold text-3xl">Tableau de bord</h1>
        <button onClick={() => setAuthed(false)} className="btn-secondary text-sm">Déconnexion</button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
        {[
          ["Pharmacies", stats.total],
          ["Ouvertes", stats.ouvertes],
          ["De garde", stats.garde],
          ["Communes", stats.communes],
          ["Départements", stats.departements],
        ].map(([label, value]) => (
          <div key={label} className="card p-4 text-center">
            <p className="text-2xl font-bold font-display">{value}</p>
            <p className="text-xs text-black/60 dark:text-white/60">{label}</p>
          </div>
        ))}
      </div>

      <h2 className="font-display font-semibold text-xl mb-4">Gestion des pharmacies</h2>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left border-b border-black/5 dark:border-white/10">
            <tr>
              <th className="p-4">Nom</th>
              <th className="p-4">Commune</th>
              <th className="p-4">De garde</th>
              <th className="p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id} className="border-b border-black/5 dark:border-white/10 last:border-0">
                <td className="p-4 font-medium">{p.nom}</td>
                <td className="p-4">{p.commune}</td>
                <td className="p-4">
                  <button
                    onClick={() => toggleGarde(p.id)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${p.deGarde ? "bg-red-500/10 text-red-600" : "bg-black/5 dark:bg-white/10"}`}
                  >
                    {p.deGarde ? "Oui" : "Non"}
                  </button>
                </td>
                <td className="p-4">
                  <button onClick={() => removePharmacy(p.id)} className="text-red-500 text-xs font-semibold">
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-black/40 mt-4">
        Ajout / modification complète et upload de photo : à connecter à l'API /backend (POST, PUT /api/pharmacies).
      </p>
    </div>
  );
}
