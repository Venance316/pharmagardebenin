"use client";
import Link from "next/link";
import { useState } from "react";
import SearchBar from "@/components/SearchBar";
import PharmacyCard from "@/components/PharmacyCard";
import { pharmacies, searchPharmacies } from "@/lib/pharmacies";

export default function HomePage() {
  const [query, setQuery] = useState("");
  const results = searchPharmacies(pharmacies, query).slice(0, 3);

  return (
    <div>
      <section className="relative overflow-hidden bg-gradient-to-b from-pharma-blue/10 to-transparent">
        <div className="max-w-5xl mx-auto px-6 py-24 text-center animate-fadeUp">
          <h1 className="font-display font-extrabold text-4xl md:text-6xl tracking-tight">
            Trouvez rapidement une pharmacie de garde,
            <br className="hidden md:block" /> partout au Bénin.
          </h1>
          <p className="mt-6 text-lg text-black/60 dark:text-white/60 max-w-2xl mx-auto">
            Localisation instantanée, itinéraire précis et contact direct — jour et nuit.
          </p>

          <div className="mt-10 max-w-xl mx-auto">
            <SearchBar onSearch={setQuery} />
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link href="/trouver-une-pharmacie" className="btn-primary">
              Trouver une pharmacie
            </Link>
            <Link href="/carte" className="btn-secondary">
              Voir la carte interactive
            </Link>
          </div>
        </div>
      </section>

      {query && (
        <section className="max-w-6xl mx-auto px-6 pb-16">
          <h2 className="font-display font-semibold text-xl mb-4">Résultats</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {results.map((p) => (
              <PharmacyCard key={p.id} pharmacy={p} />
            ))}
          </div>
        </section>
      )}

      <section className="max-w-6xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { icon: "📍", title: "Géolocalisation", text: "La pharmacie la plus proche calculée automatiquement." },
          { icon: "🕗", title: "Statuts en temps réel", text: "Ouverte, de garde ou fermée, mis à jour automatiquement." },
          { icon: "🧭", title: "Itinéraire direct", text: "Un tap pour lancer l'itinéraire Google Maps." },
        ].map((f) => (
          <div key={f.title} className="card p-6 text-center animate-fadeUp">
            <div className="text-3xl mb-3">{f.icon}</div>
            <h3 className="font-display font-semibold mb-1">{f.title}</h3>
            <p className="text-sm text-black/60 dark:text-white/60">{f.text}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
