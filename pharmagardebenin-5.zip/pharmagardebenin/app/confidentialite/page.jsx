export const metadata = { title: "Politique de confidentialité — PharmaGardeBénin" };

export default function ConfidentialitePage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16 prose-sm">
      <h1 className="font-display font-bold text-3xl mb-6">Politique de confidentialité</h1>
      <div className="space-y-5 text-black/70 dark:text-white/70 leading-relaxed text-sm">
        <p>
          PharmaGardeBénin respecte la vie privée de ses utilisateurs. Cette page décrit les
          données collectées et la manière dont elles sont utilisées.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Données collectées</h2>
        <p>
          Avec votre autorisation, nous accédons à votre position GPS afin de calculer la
          pharmacie la plus proche. Cette position n'est pas conservée sur nos serveurs.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Statistiques</h2>
        <p>
          Nous collectons des statistiques anonymes de fréquentation (nombre de recherches,
          visiteurs) afin d'améliorer le service.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Sécurité</h2>
        <p>
          Le site utilise le protocole HTTPS et des protections contre les attaques XSS et CSRF.
        </p>
        <h2 className="font-semibold text-base text-pharma-black dark:text-white">Contact</h2>
        <p>Pour toute question relative à vos données : contact@pharmagardebenin.bj</p>
      </div>
    </div>
  );
}
