"use client";
import { useState } from "react";

export default function ContactPage() {
  const [sent, setSent] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    // En production : POST vers /api/contact (backend Express)
    setSent(true);
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-16">
      <h1 className="font-display font-bold text-3xl mb-2">Contact</h1>
      <p className="text-black/60 dark:text-white/60 mb-8">
        Une question, un signalement, une pharmacie à ajouter ? Écrivez-nous.
      </p>

      <div className="flex flex-wrap gap-3 mb-8">
        <a href="tel:+22900000000" className="btn-secondary">📞 Appeler</a>
        <a href="https://wa.me/22900000000" className="btn-secondary">💬 WhatsApp</a>
        <a href="mailto:contact@pharmagardebenin.bj" className="btn-secondary">✉️ Email</a>
      </div>

      {sent ? (
        <p className="card p-6 text-pharma-blue">Message envoyé. Nous vous répondrons rapidement.</p>
      ) : (
        <form onSubmit={handleSubmit} className="card p-6 space-y-4">
          <input required placeholder="Nom complet" className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-4 py-3" />
          <input required type="email" placeholder="Email" className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-4 py-3" />
          <textarea required placeholder="Votre message" rows={5} className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-4 py-3" />
          <button type="submit" className="btn-primary w-full">Envoyer</button>
        </form>
      )}
    </div>
  );
}
