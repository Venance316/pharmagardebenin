const FAQS = [
  {
    q: "Comment savoir quelle pharmacie est de garde ce soir ?",
    a: "Ouvrez la page « Pharmacies de garde » ou la carte interactive : entre 20h30 et 07h00, seules les pharmacies officiellement de garde s'affichent en rouge.",
  },
  {
    q: "Le site fonctionne-t-il sans connexion à ma position ?",
    a: "Oui. Vous pouvez toujours rechercher manuellement par nom, commune, arrondissement ou quartier.",
  },
  {
    q: "Puis-je installer PharmaGardeBénin comme une application ?",
    a: "Oui, le site est une PWA : depuis votre navigateur mobile, choisissez « Ajouter à l'écran d'accueil ».",
  },
  {
    q: "Les informations sont-elles mises à jour automatiquement ?",
    a: "Les statuts (ouverte, de garde, fermée) changent automatiquement selon l'heure. Les plannings de garde sont saisis par notre équipe via le tableau de bord administrateur.",
  },
  {
    q: "Comment signaler une erreur sur une pharmacie ?",
    a: "Utilisez la page Contact pour nous signaler toute information incorrecte ou manquante.",
  },
];

export const metadata = { title: "FAQ — PharmaGardeBénin" };

export default function FaqPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display font-bold text-3xl mb-8">Questions fréquentes</h1>
      <div className="space-y-4">
        {FAQS.map((item) => (
          <details key={item.q} className="card p-5 group">
            <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">
              {item.q}
              <span className="text-pharma-blue group-open:rotate-45 transition">+</span>
            </summary>
            <p className="mt-3 text-black/60 dark:text-white/60 text-sm leading-relaxed">{item.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
