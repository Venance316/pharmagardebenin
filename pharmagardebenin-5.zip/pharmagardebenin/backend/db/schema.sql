CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS pharmacies (
  id SERIAL PRIMARY KEY,
  nom VARCHAR(150) NOT NULL,
  telephone VARCHAR(30) NOT NULL,
  whatsapp VARCHAR(30),
  adresse VARCHAR(255),
  departement VARCHAR(100),
  commune VARCHAR(100),
  arrondissement VARCHAR(100),
  quartier VARCHAR(100),
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  photo_url TEXT,
  horaires VARCHAR(100) DEFAULT '07h00 - 20h30',
  ouverture_normale BOOLEAN DEFAULT TRUE,
  de_garde BOOLEAN DEFAULT FALSE,
  email VARCHAR(150),
  site_web VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pharmacies_location ON pharmacies USING GIST (location);

CREATE TABLE IF NOT EXISTS gardes (
  id SERIAL PRIMARY KEY,
  pharmacie_id INTEGER REFERENCES pharmacies(id) ON DELETE CASCADE,
  date_debut DATE NOT NULL,
  date_fin DATE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS utilisateurs (
  id SERIAL PRIMARY KEY,
  email VARCHAR(150) UNIQUE NOT NULL,
  mot_de_passe_hash TEXT NOT NULL,
  role VARCHAR(20) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS recherches (
  id SERIAL PRIMARY KEY,
  terme VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Exemple de requête PostGIS : pharmacies à moins de 5 km d'un point
-- SELECT *, ST_Distance(location, ST_MakePoint($lng, $lat)::geography) AS distance
-- FROM pharmacies
-- WHERE ST_DWithin(location, ST_MakePoint($lng, $lat)::geography, 5000)
-- ORDER BY distance ASC;
