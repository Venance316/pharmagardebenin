const jwt = require("jsonwebtoken");

function requireAuth(rolesAutorises = ["admin"]) {
  return (req, res, next) => {
    const header = req.headers.authorization;
    if (!header || !header.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Authentification requise." });
    }
    try {
      const token = header.split(" ")[1];
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      if (!rolesAutorises.includes(payload.role)) {
        return res.status(403).json({ error: "Accès refusé." });
      }
      req.user = payload;
      next();
    } catch {
      return res.status(401).json({ error: "Token invalide ou expiré." });
    }
  };
}

module.exports = { requireAuth };
