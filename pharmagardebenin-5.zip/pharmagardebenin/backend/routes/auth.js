const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("../db/pool");

const router = express.Router();

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email et mot de passe requis." });
  }

  try {
    const { rows } = await pool.query("SELECT * FROM utilisateurs WHERE email = $1", [email]);
    const user = rows[0];
    if (!user) return res.status(401).json({ error: "Identifiants incorrects." });

    const valid = await bcrypt.compare(password, user.mot_de_passe_hash);
    if (!valid) return res.status(401).json({ error: "Identifiants incorrects." });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "8h" }
    );
    res.json({ token, role: user.role });
  } catch (err) {
    res.status(500).json({ error: "Erreur serveur." });
  }
});

module.exports = router;
