const express = require("express");
const pool = require("../db/pool");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/pharmacies?lat=&lng=&rayon_km=&q=
router.get("/", async (req, res) => {
  const { lat, lng, rayon_km = 10, q } = req.query;

  try {
    if (lat && lng) {
      const { rows } = await pool.query(
        `SELECT *, ST_Distance(location, ST_MakePoint($1, $2)::geography) / 1000 AS distance_km
         FROM pharmacies
         WHERE ST_DWithin(location, ST_MakePoint($1, $2)::geography, $3 * 1000)
         ORDER BY distance_km ASC`,
        [lng, lat, rayon_km]
      );
      return res.json(rows);
    }

    if (q) {
      const { rows } = await pool.query(
        `SELECT * FROM pharmacies
         WHERE nom ILIKE $1 OR commune ILIKE $1 OR quartier ILIKE $1 OR arrondissement ILIKE $1
         ORDER BY nom ASC`,
        [`%${q}%`]
      );
      return res.json(rows);
    }

    const { rows } = await pool.query("SELECT * FROM pharmacies ORDER BY nom ASC");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: "Erreur lors de la récupération des pharmacies." });
  }
});

// POST /api/pharmacies (admin)
router.post("/", requireAuth(["admin"]), async (req, res) => {
  const {
    nom, telephone, whatsapp, adresse, departement, commune,
    arrondissement, quartier, latitude, longitude, photo_url,
    horaires, email, site_web,
  } = req.body;

  try {
    const { rows } = await pool.query(
      `INSERT INTO pharmacies
        (nom, telephone, whatsapp, adresse, departement, commune, arrondissement, quartier,
         location, photo_url, horaires, email, site_web)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8, ST_MakePoint($9,$10)::geography, $11,$12,$13)
       RETURNING *`,
      [nom, telephone, whatsapp, adresse, departement, commune, arrondissement, quartier,
        longitude, latitude, photo_url, email, site_web]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: "Erreur lors de la création." });
  }
});

// PUT /api/pharmacies/:id (admin) — mise à jour horaires / statut de garde / infos
router.put("/:id", requireAuth(["admin"]), async (req, res) => {
  const { id } = req.params;
  const { horaires, ouverture_normale, de_garde, telephone, whatsapp } = req.body;

  try {
    const { rows } = await pool.query(
      `UPDATE pharmacies SET
        horaires = COALESCE($1, horaires),
        ouverture_normale = COALESCE($2, ouverture_normale),
        de_garde = COALESCE($3, de_garde),
        telephone = COALESCE($4, telephone),
        whatsapp = COALESCE($5, whatsapp),
        updated_at = NOW()
       WHERE id = $6 RETURNING *`,
      [horaires, ouverture_normale, de_garde, telephone, whatsapp, id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Pharmacie introuvable." });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: "Erreur lors de la mise à jour." });
  }
});

// DELETE /api/pharmacies/:id (admin)
router.delete("/:id", requireAuth(["admin"]), async (req, res) => {
  try {
    await pool.query("DELETE FROM pharmacies WHERE id = $1", [req.params.id]);
    res.status(204).end();
  } catch (err) {
    res.status(500).json({ error: "Erreur lors de la suppression." });
  }
});

// GET /api/pharmacies/stats (admin)
router.get("/stats/dashboard", requireAuth(["admin"]), async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        COUNT(*)::int AS total,
        COUNT(*) FILTER (WHERE ouverture_normale)::int AS ouvertes,
        COUNT(*) FILTER (WHERE de_garde)::int AS de_garde,
        COUNT(DISTINCT commune)::int AS communes,
        COUNT(DISTINCT departement)::int AS departements
      FROM pharmacies
    `);
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: "Erreur lors du calcul des statistiques." });
  }
});

module.exports = router;
